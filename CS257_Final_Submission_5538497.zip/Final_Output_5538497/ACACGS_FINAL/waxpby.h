#ifndef WAXBY_H
#define WAXBY_H
int waxpby (const int n, const double alpha, const double * const x, const double beta, const double * const y, double * const w);
#endif
