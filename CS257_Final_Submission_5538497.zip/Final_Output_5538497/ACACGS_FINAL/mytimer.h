#ifndef MYTIMER_H
#define MYTIMER_H
double mytimer(void);
#endif
