#ifndef DDOT_H
#define DDOT_H
int ddot (const int n, const double * const x, const double * const y, double * const result);
#endif
